package com.example.test;

import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.content.Intent;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.IOException;

public class MainActivity extends AppCompatActivity {
    ImageButton cctvButton, diaryButton, ledButton, houseButton;
    TextView humText, tempText, dustText;

    private Handler handler = new Handler();
    private Runnable getDataRunnable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        cctvButton = findViewById(R.id.cctvButton);
        diaryButton = findViewById(R.id.diaryButton);
        ledButton = findViewById(R.id.ledButton);
        houseButton = findViewById(R.id.houseButton);
        humText = findViewById(R.id.humText);
        tempText = findViewById(R.id.tempText);
        dustText = findViewById(R.id.dustText);

        cctvButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), cctvActivity.class);
                startActivity(intent);
            }
        });

        diaryButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), diaryActivity.class);
                startActivity(intent);
            }
        });

        houseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // AsyncTask를 실행하여 워터펌프를 작동시킵니다.
                new ActivateWaterPumpTask().execute();
            }
        });

        // 주기적으로 데이터를 가져오는 Runnable 설정
        getDataRunnable = new Runnable() {
            @Override
            public void run() {
                // AsyncTask를 실행하여 센서 데이터를 가져옵니다.
                new RetrieveSensorData().execute();
                // 주기적으로 실행하려면 다시 호출
                handler.postDelayed(this, 5000); // 5초마다 데이터 갱신 (5000ms = 5초)
            }
        };

        // 초기 데이터 로드
        getDataRunnable.run();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // 액티비티가 종료될 때 Runnable 중지
        handler.removeCallbacks(getDataRunnable);
    }

    private class RetrieveSensorData extends AsyncTask<Void, Void, String> {
        @Override
        protected String doInBackground(Void... voids) {
            OkHttpClient client = new OkHttpClient();

            // "YOUR_ESP_IP_ADDRESS"를 ESP8266의 실제 IP 주소로 바꿉니다.
            String url = "http://192.168.0.2/";

            Request request = new Request.Builder()
                    .url(url)
                    .build();

            try {
                Response response = client.newCall(request).execute();
                return response.body().string();
            } catch (IOException e) {
                e.printStackTrace();
                return null;
            }
        }

        @Override
        protected void onPostExecute(String result) {
            if (result != null) {
                try {
                    JSONObject jsonData = new JSONObject(result);
                    double temperature = jsonData.getDouble("temperature");
                    double humidity = jsonData.getDouble("humidity");
                    // 서버에서 전달한 먼지 데이터가 있다고 가정
                    int dust = jsonData.getInt("soil_moisture") * 100 / 1024;

                    // UI 갱신
                    tempText.setText("온도: " + temperature + " °C");
                    humText.setText("습도: " + humidity + " %");
                    dustText.setText("토양수분: " + dust + " %");
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private class ActivateWaterPumpTask extends AsyncTask<Void, Void, String> {
        @Override
        protected String doInBackground(Void... voids) {
            OkHttpClient client = new OkHttpClient();

            // "YOUR_ESP_IP_ADDRESS/waterpump/on"를 ESP8266의 실제 IP 주소로 바꿉니다.
            String url = "http://192.168.0.2/waterpump/on";

            Request request = new Request.Builder()
                    .url(url)
                    .build();

            try {
                Response response = client.newCall(request).execute();
                return response.body().string();
            } catch (IOException e) {
                e.printStackTrace();
                return null;
            }
        }

        @Override
        protected void onPostExecute(String result) {
            if (result != null) {
                // 결과를 처리하는 코드를 추가하세요.
                Log.d("ActivateWaterPumpTask", "Result: " + result);

                // 5초 후에 워터펌프를 멈추는 AsyncTask를 실행합니다.
                new DeactivateWaterPumpTask().execute();
            }
        }
    }

    private class DeactivateWaterPumpTask extends AsyncTask<Void, Void, String> {
        @Override
        protected String doInBackground(Void... voids) {
            OkHttpClient client = new OkHttpClient();

            // "YOUR_ESP_IP_ADDRESS/waterpump/off"를 ESP8266의 실제 IP 주소로 바꿉니다.
            String url = "http://192.168.0.2/waterpump/off";

            Request request = new Request.Builder()
                    .url(url)
                    .build();

            try {
                Response response = client.newCall(request).execute();
                return response.body().string();
            } catch (IOException e) {
                e.printStackTrace();
                return null;
            }
        }

        @Override
        protected void onPostExecute(String result) {
            if (result != null) {
                // 결과를 처리하는 코드를 추가하세요.
                Log.d("DeactivateWaterPumpTask", "Result: " + result);
            }
        }
        private void showToast(String message) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
                }
            });
        }

    }
}
