package com.example.test;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class diaryActivity extends AppCompatActivity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_diary);
    }
}